export default function Home() {
  return (
    <div style={{ textAlign: 'center', paddingTop: '50px' }}>
      <h1>Welcome to My Next.js App</h1>
      <p>This is a super basic web app using Next.js</p>
    </div>
  );
}
