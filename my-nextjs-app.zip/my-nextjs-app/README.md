# My Next.js App

This is a super basic web app built with [Next.js](https://nextjs.org/).

## Getting Started

```bash
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Build for Production

```bash
npm run build
npm start
```
